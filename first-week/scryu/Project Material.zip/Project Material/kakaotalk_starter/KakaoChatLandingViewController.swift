//
//  ViewController.swift
//  Twitter_starter
//
//  Created by James Kim on 7/27/20.
//  Copyright © 2020 James Kim. All rights reserved.
//

import UIKit

class KakaoChatLandingViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    private let list = Message.dummyList
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }

    func setupTableView() {

    }

}

extension KakaoChatLandingViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "talkCell", for: indexPath) as? KakaoChatTableViewCell else {
            return UITableViewCell()
        }
        
        cell.configure(message: list[indexPath.row])
        return cell
        
    }
}

