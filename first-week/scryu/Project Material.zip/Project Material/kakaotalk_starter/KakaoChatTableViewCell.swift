//
//  KakaoChatTableViewCell.swift
//  Twitter_starter
//
//  Created by James Kim on 7/27/20.
//  Copyright © 2020 James Kim. All rights reserved.
//

import UIKit

class KakaoChatTableViewCell: UITableViewCell {

    @IBOutlet var senderImageView: UIImageView!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var lastMessagelabel: UILabel!
    @IBOutlet var lastSentDateLabel: UILabel!
    
    
    func configure(message: Message) {
        self.senderImageView.image = message.senderImage
        self.nameLabel.text = message.senderName
        self.lastMessagelabel.text = message.lastMessage
        self.lastSentDateLabel.text = message.lastSentDate
        
    }
}
