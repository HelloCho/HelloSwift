//
//  ViewController.swift
//  miniProject2
//
//  Created by Kim Kyung Dong on 10/19/20.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var userTableView: UITableView!
    
    let list = Message.dummyList
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KakaoTalkTableViewCell", for: indexPath) as! KakaoTalkTableViewCell
        
        cell.userDateLabel.text = list[indexPath.row].lastSentDate
        cell.userMessageLabel.text = list[indexPath.row].lastMessage
        cell.userNameLabel.text = list[indexPath.row].senderName
        cell.userImage.image = UIImage(named: list[indexPath.row].senderImageName)
        
        return cell
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}
